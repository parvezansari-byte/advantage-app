// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import '../main.dart';
import '../services/api_service.dart';
import '../services/auth_service.dart';
import 'login_screen.dart';
import 'stock_screen.dart';
import 'planner_screen.dart';
import 'xray_screen.dart';
import 'calculator_screen.dart';
import 'lifestyle_screen.dart';
import 'life_goal_screen.dart';
import 'core_wealth_screen.dart';
import 'news_screen.dart';
import 'sectors_screen.dart';
import 'chart_screen.dart';
import 'options_screen.dart';
import 'holdings_screen.dart';
import 'backtest_screen.dart';
import 'portfolio_screen.dart';
import 'tax_screen.dart';
import 'finance_screen.dart';
import '../services/auth_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _searchCtrl = TextEditingController();
  bool? _apiUp; // null = still checking
  List<String> _allStocks = []; // the ~500 searchable stocks

  @override
  void initState() {
    super.initState();
    _checkApi();
    _loadStocks();
  }

  Future<void> _checkApi() async {
    final up = await ApiService.ping();
    if (mounted) setState(() => _apiUp = up);
  }

  Future<void> _loadStocks() async {
    try {
      final list = await ApiService.getStockList();
      if (mounted) setState(() => _allStocks = list);
    } catch (_) {
      // search still works by typing a full symbol even if the list fails
    }
  }

  void _openStock(String symbol) {
    final s = symbol.trim().toUpperCase();
    if (s.isEmpty) return;
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => StockScreen(symbol: s)),
    );
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ---- brand ----
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: Brand.gold,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.search,
                        color: Brand.vault, size: 26),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'My Research Platform',
                      style: TextStyle(
                        color: Brand.gold,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.logout, color: Brand.mint, size: 20),
                    tooltip: 'Sign out',
                    onPressed: () async {
                      await AuthService.logout();
                      if (!context.mounted) return;
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (_) => const LoginScreen()),
                      );
                    },
                  ),
                ],
              ),
              if (AuthService.name != null && AuthService.name!.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('Signed in as ${AuthService.name}',
                      style: TextStyle(
                          color: Brand.mint.withValues(alpha: 0.6),
                          fontSize: 11)),
                ),
              const SizedBox(height: 8),
              Container(width: 50, height: 3, color: Brand.gold),
              const SizedBox(height: 24),

              const Text(
                'Stop taking tips.',
                style: TextStyle(
                    color: Brand.paper,
                    fontSize: 26,
                    fontWeight: FontWeight.bold),
              ),
              const Text(
                'Start doing research.',
                style: TextStyle(
                    color: Brand.gold,
                    fontSize: 26,
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),

              // ---- connection status (honest about failures) ----
              _ConnectionBanner(apiUp: _apiUp, onRetry: _checkApi),
              const SizedBox(height: 20),

              // ---- search with autocomplete over ~500 stocks ----
              Autocomplete<String>(
                optionsBuilder: (TextEditingValue value) {
                  final q = value.text.trim().toUpperCase();
                  if (q.isEmpty) return const Iterable<String>.empty();
                  return _allStocks
                      .where((s) => s.contains(q))
                      .take(30);
                },
                onSelected: (s) => _openStock(s),
                fieldViewBuilder:
                    (context, controller, focusNode, onSubmit) {
                  return TextField(
                    controller: controller,
                    focusNode: focusNode,
                    textCapitalization: TextCapitalization.characters,
                    style: const TextStyle(color: Brand.paper),
                    decoration: InputDecoration(
                      hintText: _allStocks.isEmpty
                          ? 'Loading stock list…'
                          : 'Search ${_allStocks.length} stocks — e.g. RELIANCE',
                      prefixIcon:
                          const Icon(Icons.search, color: Brand.mint),
                    ),
                    onSubmitted: (v) {
                      onSubmit();
                      _openStock(v);
                    },
                  );
                },
                optionsViewBuilder: (context, onSelected, options) {
                  return Align(
                    alignment: Alignment.topLeft,
                    child: Material(
                      color: Brand.fern,
                      elevation: 4,
                      borderRadius: BorderRadius.circular(12),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(
                            maxHeight: 280, maxWidth: 360),
                        child: ListView(
                          padding: EdgeInsets.zero,
                          shrinkWrap: true,
                          children: options
                              .map((s) => ListTile(
                                    dense: true,
                                    title: Text(s,
                                        style: const TextStyle(
                                            color: Brand.paper)),
                                    onTap: () => onSelected(s),
                                  ))
                              .toList(),
                        ),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: Brand.gold,
                    foregroundColor: Brand.vault,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: () => _openStock(_searchCtrl.text),
                  child: const Text('Analyse',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 28),

              // ---- Financial Planner ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const PlannerScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.savings,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Financial Planner',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'Risk profile + how much to invest monthly',
                                style: TextStyle(
                                    color: Brand.mint
                                        .withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Portfolio X-ray ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const XrayScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.biotech, color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Portfolio X-ray',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'Do your funds secretly own the same stocks?',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Calculators ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const CalculatorScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.calculate,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Calculators',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'SIP, lumpsum, goal, step-up, SWP and EMI',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Lifestyle & Balance Sheet ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const LifestyleScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.account_balance_wallet,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Lifestyle & Balance Sheet',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'Cashflow, net worth, house, car and EMI vs SIP',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Life Goal & Protection ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const LifeGoalScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.family_restroom,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Life Goal & Protection',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'Children, retirement, insurance and rebalancing',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Core Wealth Planning ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const CoreWealthScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.account_balance,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Core Wealth Planning',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'Goal check, allocation and live fund returns',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Market Terminal ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const NewsScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.newspaper,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Market Terminal',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'FII/DII flows and live market news',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Sector Performance ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SectorsScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.donut_small,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Sector Performance',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'Which sectors are leading and lagging',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Live Chart ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const ChartScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.candlestick_chart,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Live Chart',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'Intraday and long-term price charts',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Option Chain ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const OptionsScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.stacked_bar_chart,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Option Chain',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'PCR, max pain and open interest by strike',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Holdings Explorer ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const HoldingsScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.travel_explore,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Holdings Explorer',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'What funds own, and how much they overlap',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Strategy Backtest ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const BacktestScreen()),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.science_outlined,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Strategy Backtest',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'Test a strategy against real price history',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- My Portfolio ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () {
                    // Holdings are stored per user, so this needs a session.
                    final email = AuthService.email;
                    if (email == null || email.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Sign in to track your portfolio'),
                        ),
                      );
                      return;
                    }
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => PortfolioScreen(email: email)),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(
                              Icons.account_balance_wallet_outlined,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('My Portfolio',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'Track your holdings and live P&L',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Tax Calculator ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () {
                    final email = AuthService.email;
                    if (email == null || email.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Sign in to use the tax calculator'),
                        ),
                      );
                      return;
                    }
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => TaxScreen(userEmail: email)),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.receipt_long_outlined,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Tax Calculator',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'STCG/LTCG from your real trades',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // ---- Finance Tracker ----
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () {
                    final email = AuthService.email;
                    if (email == null || email.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Sign in to use the finance tracker'),
                        ),
                      );
                      return;
                    }
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => FinanceScreen(userEmail: email)),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Brand.gold.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.savings_outlined,
                              color: Brand.gold),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Finance Tracker',
                                  style: TextStyle(
                                      color: Brand.paper,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text(
                                'Spending, loans, debt & pending dues',
                                style: TextStyle(
                                    color: Brand.mint.withValues(alpha: 0.75),
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Brand.mint),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              const Text('POPULAR',
                  style: TextStyle(
                      color: Brand.mint,
                      fontSize: 11,
                      letterSpacing: 1.5,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  'RELIANCE',
                  'TCS',
                  'HDFCBANK',
                  'INFY',
                  'ICICIBANK',
                  'ITC',
                ].map((s) => ActionChip(
                      label: Text(s),
                      backgroundColor: Brand.fern.withValues(alpha: 0.4),
                      labelStyle: const TextStyle(color: Brand.paper),
                      side: BorderSide(
                          color: Brand.mint.withValues(alpha: 0.15)),
                      onPressed: () => _openStock(s),
                    )).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Shows whether the phone can actually reach the Python API.
/// This is the #1 thing that goes wrong, so we surface it clearly
/// instead of letting the user hit a mysterious error later.
class _ConnectionBanner extends StatelessWidget {
  final bool? apiUp;
  final VoidCallback onRetry;

  const _ConnectionBanner({required this.apiUp, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    if (apiUp == null) {
      return const Card(
        child: ListTile(
          leading: SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
          title: Text('Connecting to the API…',
              style: TextStyle(color: Brand.mint, fontSize: 13)),
        ),
      );
    }

    if (apiUp == true) {
      return Card(
        child: ListTile(
          leading: const Icon(Icons.check_circle, color: Brand.green),
          title: const Text('Connected to backend',
              style: TextStyle(color: Brand.green, fontSize: 13)),
          subtitle: Text(ApiService.baseUrl,
              style: TextStyle(
                  color: Brand.mint.withValues(alpha: 0.6), fontSize: 11)),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.error_outline, color: Brand.red),
                SizedBox(width: 10),
                Text("Can't reach the API",
                    style: TextStyle(
                        color: Brand.red, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Check that:\n'
              '1. The Python API is running (uvicorn api:app)\n'
              '2. The URL is right for where you are running this\n'
              '   • Emulator → http://10.0.2.2:8000\n'
              '   • Real phone → http://<your-PC-IP>:8000',
              style: TextStyle(
                  color: Brand.mint.withValues(alpha: 0.8),
                  fontSize: 12,
                  height: 1.5),
            ),
            const SizedBox(height: 10),
            TextButton(onPressed: onRetry, child: const Text('Retry')),
          ],
        ),
      ),
    );
  }
}
