// lib/main.dart
//
// My Research Platform — Flutter app
// Talks to your Python FastAPI backend (api.py).

import 'package:flutter/material.dart';
import 'screens/main_shell.dart';
import 'screens/login_screen.dart';
import 'services/auth_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Restore a saved session so returning users skip the login screen.
  await AuthService.restore();
  runApp(const ResearchApp());
}

/// Brand colours — same identity as the web platform.
class Brand {
  static const vault = Color(0xFF0A2E24);   // deep green background
  static const fern = Color(0xFF1C5943);    // lighter green
  static const gold = Color(0xFFC9A227);    // accent
  static const paper = Color(0xFFFBFAF7);   // near-white text
  static const mint = Color(0xFFDCEFE6);    // muted text
  static const green = Color(0xFF10B981);   // gains
  static const red = Color(0xFFEF4444);     // losses
}

class ResearchApp extends StatelessWidget {
  const ResearchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Research Platform',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: Brand.vault,
        colorScheme: const ColorScheme.dark(
          primary: Brand.gold,
          surface: Brand.vault,
          onSurface: Brand.paper,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Brand.vault,
          foregroundColor: Brand.gold,
          elevation: 0,
          centerTitle: false,
        ),
        cardTheme: CardThemeData(
          color: Brand.fern.withValues(alpha: 0.35),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(color: Brand.mint.withValues(alpha: 0.12)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Brand.fern.withValues(alpha: 0.3),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          hintStyle: TextStyle(color: Brand.mint.withValues(alpha: 0.5)),
        ),
      ),
      home: AuthService.isLoggedIn
          ? const MainShell()
          : const LoginScreen(),
    );
  }
}
