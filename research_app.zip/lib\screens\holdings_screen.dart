// lib/screens/holdings_screen.dart
// ---------------------------------------------------------------------------
// Holdings Explorer: what funds actually own.
//
// Three views — which funds hold a given stock, one fund's full portfolio,
// and the overlap between two funds. Data is from AMC monthly disclosures,
// which cover only the fund houses that publish machine-readable factsheets,
// so the coverage line is shown wherever it matters.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../main.dart';
import '../services/api_service.dart';

// ===========================================================================
// FORMATTING
// ===========================================================================

String _group(int n) {
  final s = n.abs().toString();
  if (s.length <= 3) return '${n < 0 ? '-' : ''}$s';
  final last3 = s.substring(s.length - 3);
  var rest = s.substring(0, s.length - 3);
  final buf = <String>[];
  while (rest.length > 2) {
    buf.insert(0, rest.substring(rest.length - 2));
    rest = rest.substring(0, rest.length - 2);
  }
  if (rest.isNotEmpty) buf.insert(0, rest);
  return '${n < 0 ? '-' : ''}${buf.join(',')},$last3';
}

String _pct(num? v, {int dp = 2}) =>
    v == null ? '—' : '${v.toStringAsFixed(dp)}%';

/// Disclosures are in lakh; crore reads better above a point.
String _lakhToMoney(num? lakh) {
  if (lakh == null) return '—';
  final cr = lakh / 100;
  if (cr >= 1000) return '₹${_group((cr / 1000).round())}k Cr';
  if (cr >= 1) return '₹${cr.toStringAsFixed(1)} Cr';
  return '₹${lakh.toStringAsFixed(1)} L';
}

String _qty(num? v) => v == null ? '—' : _group(v.round());

/// Bands mirror the API's own verdict so colour and words agree.
Color _overlapColour(String band) => switch (band) {
      'very_high' => Brand.red,
      'high' => Brand.gold,
      'moderate' => Brand.gold,
      _ => Brand.green,
    };

const _sectorPalette = [
  Brand.gold,
  Brand.green,
  Brand.mint,
  Color(0xFF8B9F7E),
  Color(0xFFD4A574),
  Color(0xFF7FA88B),
  Color(0xFFB8956A),
  Color(0xFF6B8E7F),
  Color(0xFFC9B47E),
];

// ===========================================================================
// SCREEN
// ===========================================================================

class HoldingsScreen extends StatefulWidget {
  const HoldingsScreen({super.key});

  @override
  State<HoldingsScreen> createState() => _HoldingsScreenState();
}

class _HoldingsScreenState extends State<HoldingsScreen> {
  Map<String, dynamic>? _summary;
  List<dynamic> _funds = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final s = await ApiService.getHoldingsSummary();
      final f = await ApiService.getHoldingsFunds();
      if (!mounted) return;
      setState(() {
        _summary = s;
        _funds = f;
      });
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: Brand.vault,
        appBar: AppBar(
          backgroundColor: Brand.vault,
          foregroundColor: Brand.paper,
          elevation: 0,
          title: const Text('Holdings Explorer',
              style:
                  TextStyle(color: Brand.gold, fontWeight: FontWeight.bold)),
          bottom: const TabBar(
            labelColor: Brand.gold,
            unselectedLabelColor: Brand.mint,
            indicatorColor: Brand.gold,
            labelStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            tabs: [
              Tab(text: 'Who holds it'),
              Tab(text: 'Portfolio'),
              Tab(text: 'Overlap'),
            ],
          ),
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator(color: Brand.gold))
            : _error != null
                ? _ErrorState(message: _error!, onRetry: _load)
                : Column(
                    children: [
                      _CoverageBar(summary: _summary!),
                      Expanded(
                        child: TabBarView(
                          children: [
                            const _StockSearchTab(),
                            _PortfolioTab(funds: _funds),
                            _OverlapTab(funds: _funds),
                          ],
                        ),
                      ),
                    ],
                  ),
      ),
    );
  }
}

/// States plainly what the snapshot covers — partial coverage misread as
/// complete would make "no fund holds this" look like a fact.
class _CoverageBar extends StatelessWidget {
  const _CoverageBar({required this.summary});

  final Map<String, dynamic> summary;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => showDialog(
        context: context,
        builder: (_) => AlertDialog(
          backgroundColor: Brand.fern,
          title: const Text('Coverage',
              style: TextStyle(color: Brand.paper, fontSize: 15)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Portfolio disclosures as on ${summary['as_on']}, covering '
                '${summary['funds']} funds from ${summary['amcs']} AMCs.',
                style: TextStyle(
                    color: Brand.mint.withValues(alpha: 0.9),
                    fontSize: 12,
                    height: 1.45),
              ),
              const SizedBox(height: 10),
              Text(
                ((summary['amc_names'] as List?) ?? []).join(' · '),
                style: TextStyle(
                    color: Brand.gold.withValues(alpha: 0.85),
                    fontSize: 11,
                    height: 1.5),
              ),
              const SizedBox(height: 10),
              Text(
                'Funds from other AMCs are not in this dataset, so an absent '
                'fund does not mean it holds nothing.',
                style: TextStyle(
                    color: Brand.mint.withValues(alpha: 0.6),
                    fontSize: 10.5,
                    height: 1.4),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close',
                  style: TextStyle(color: Brand.gold)),
            ),
          ],
        ),
      ),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        color: Brand.fern.withValues(alpha: 0.25),
        child: Row(
          children: [
            Icon(Icons.info_outline,
                size: 12, color: Brand.mint.withValues(alpha: 0.7)),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                '${summary['funds']} funds · ${summary['amcs']} AMCs · '
                'as on ${summary['as_on']}',
                style: TextStyle(
                    color: Brand.mint.withValues(alpha: 0.75), fontSize: 10.5),
              ),
            ),
            Text('Details',
                style: TextStyle(
                    color: Brand.gold.withValues(alpha: 0.8), fontSize: 10)),
          ],
        ),
      ),
    );
  }
}

// ===========================================================================
// SHARED WIDGETS
// ===========================================================================

/// Horizontal weight bar used by every list in this screen.
class _WeightBar extends StatelessWidget {
  const _WeightBar({
    required this.label,
    required this.pct,
    required this.maxPct,
    this.sub,
    this.colour = Brand.gold,
  });

  final String label;
  final num? pct;
  final double maxPct;
  final String? sub;
  final Color colour;

  @override
  Widget build(BuildContext context) {
    final value = (pct ?? 0).toDouble();
    final ratio = maxPct > 0 ? (value / maxPct).clamp(0.0, 1.0) : 0.0;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: Brand.paper, fontSize: 11.5)),
              ),
              const SizedBox(width: 8),
              Text(_pct(pct),
                  style: TextStyle(
                      color: colour,
                      fontSize: 11.5,
                      fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(3),
                  child: SizedBox(
                    height: 5,
                    child: Row(
                      children: [
                        Expanded(
                          flex: math.max((ratio * 1000).round(), 1),
                          child: Container(color: colour),
                        ),
                        Expanded(
                          flex: math.max(((1 - ratio) * 1000).round(), 1),
                          child: Container(
                              color: Brand.fern.withValues(alpha: 0.5)),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              if (sub != null) ...[
                const SizedBox(width: 8),
                Text(sub!,
                    style: TextStyle(
                        color: Brand.mint.withValues(alpha: 0.6),
                        fontSize: 9.5)),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({
    required this.label,
    required this.value,
    this.colour = Brand.gold,
  });

  final String label;
  final String value;
  final Color colour;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
        decoration: BoxDecoration(
          color: Brand.fern.withValues(alpha: 0.3),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          children: [
            Text(label,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Brand.mint.withValues(alpha: 0.7),
                    fontSize: 8.5,
                    letterSpacing: 0.4,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 5),
            FittedBox(
              child: Text(value,
                  style: TextStyle(
                      color: colour,
                      fontSize: 16,
                      fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}

/// Picks one fund via a searchable bottom sheet — 226 funds is too many for
/// a dropdown.
class _FundPicker extends StatelessWidget {
  const _FundPicker({
    required this.funds,
    required this.label,
    required this.selected,
    required this.onSelect,
  });

  final List<dynamic> funds;
  final String label;
  final String? selected;
  final ValueChanged<Map<String, dynamic>> onSelect;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (_) => _FundPickerSheet(funds: funds, onSelect: onSelect),
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
        decoration: BoxDecoration(
          color: Brand.fern.withValues(alpha: 0.35),
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: Brand.mint.withValues(alpha: 0.22)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: TextStyle(
                          color: Brand.mint.withValues(alpha: 0.7),
                          fontSize: 9.5,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 3),
                  Text(selected ?? 'Tap to choose',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: selected == null
                              ? Brand.mint.withValues(alpha: 0.5)
                              : Brand.paper,
                          fontSize: 12,
                          height: 1.25,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            Icon(Icons.expand_more,
                color: Brand.mint.withValues(alpha: 0.7), size: 20),
          ],
        ),
      ),
    );
  }
}

class _FundPickerSheet extends StatefulWidget {
  const _FundPickerSheet({required this.funds, required this.onSelect});

  final List<dynamic> funds;
  final ValueChanged<Map<String, dynamic>> onSelect;

  @override
  State<_FundPickerSheet> createState() => _FundPickerSheetState();
}

class _FundPickerSheetState extends State<_FundPickerSheet> {
  final _ctrl = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final needle = _query.trim().toLowerCase();
    final filtered = needle.isEmpty
        ? widget.funds
        : widget.funds.where((f) {
            final m = f as Map;
            return '${m['fund']} ${m['amc']}'.toLowerCase().contains(needle);
          }).toList();

    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      builder: (context, controller) => Container(
        decoration: const BoxDecoration(
          color: Brand.vault,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding:
            EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Brand.mint.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
              child: TextField(
                controller: _ctrl,
                autofocus: true,
                style: const TextStyle(color: Brand.paper, fontSize: 13),
                onChanged: (v) => setState(() => _query = v),
                decoration: InputDecoration(
                  hintText: 'Filter ${widget.funds.length} funds',
                  hintStyle:
                      TextStyle(color: Brand.mint.withValues(alpha: 0.5)),
                  prefixIcon:
                      const Icon(Icons.search, color: Brand.mint, size: 20),
                  filled: true,
                  fillColor: Brand.fern.withValues(alpha: 0.35),
                  isDense: true,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 12),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: Brand.mint.withValues(alpha: 0.25)),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: Brand.gold),
                  ),
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                controller: controller,
                itemCount: filtered.length,
                itemBuilder: (context, i) {
                  final f = (filtered[i] as Map).cast<String, dynamic>();
                  return ListTile(
                    dense: true,
                    title: Text('${f['fund']}',
                        style: const TextStyle(
                            color: Brand.paper, fontSize: 12.5, height: 1.3)),
                    subtitle: Text(
                        '${f['amc']}  ·  ${f['holdings']} holdings',
                        style: TextStyle(
                            color: Brand.mint.withValues(alpha: 0.65),
                            fontSize: 10.5)),
                    onTap: () {
                      Navigator.pop(context);
                      widget.onSelect(f);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inventory_2_outlined,
                size: 36, color: Brand.mint.withValues(alpha: 0.5)),
            const SizedBox(height: 14),
            Text(message,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Brand.mint.withValues(alpha: 0.85),
                    fontSize: 12.5,
                    height: 1.4)),
            const SizedBox(height: 16),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: Brand.gold,
                foregroundColor: Brand.vault,
              ),
              onPressed: onRetry,
              icon: const Icon(Icons.refresh, size: 16),
              label: const Text('Try again'),
            ),
          ],
        ),
      ),
    );
  }
}

// ===========================================================================
// TAB 1 — WHO HOLDS THIS STOCK
// ===========================================================================

class _StockSearchTab extends StatefulWidget {
  const _StockSearchTab();

  @override
  State<_StockSearchTab> createState() => _StockSearchTabState();
}

class _StockSearchTabState extends State<_StockSearchTab> {
  final _ctrl = TextEditingController();
  Map<String, dynamic>? _data;
  int _picked = 0;
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final q = _ctrl.text.trim();
    if (q.length < 3) {
      setState(() => _error = 'Type at least 3 characters');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
      _data = null;
      _picked = 0;
    });
    try {
      final d = await ApiService.getStockHolders(q);
      if (mounted) setState(() => _data = d);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final securities = (_data?['securities'] as List?) ?? [];
    final current = securities.isEmpty
        ? null
        : (securities[_picked.clamp(0, securities.length - 1)] as Map)
            .cast<String, dynamic>();
    final holders = (current?['holders'] as List?) ?? [];
    final maxWeight = holders.isEmpty
        ? 1.0
        : ((holders.first as Map)['pct_nav'] as num? ?? 1).toDouble();

    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
      children: [
        TextField(
          controller: _ctrl,
          style: const TextStyle(color: Brand.paper, fontSize: 13),
          textInputAction: TextInputAction.search,
          onSubmitted: (_) => _search(),
          decoration: InputDecoration(
            hintText: 'Stock name — e.g. HDFC Bank, Infosys, Zomato',
            hintStyle: TextStyle(
                color: Brand.mint.withValues(alpha: 0.5), fontSize: 12.5),
            prefixIcon: const Icon(Icons.search, color: Brand.mint, size: 20),
            suffixIcon: _loading
                ? const Padding(
                    padding: EdgeInsets.all(14),
                    child: SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Brand.gold),
                    ),
                  )
                : IconButton(
                    icon: const Icon(Icons.arrow_forward,
                        color: Brand.gold, size: 20),
                    onPressed: _search,
                  ),
            filled: true,
            fillColor: Brand.fern.withValues(alpha: 0.35),
            isDense: true,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Brand.mint.withValues(alpha: 0.25)),
            ),
            focusedBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Brand.gold),
            ),
          ),
        ),

        if (_error != null)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(_error!,
                style: const TextStyle(color: Brand.red, fontSize: 12)),
          ),

        if (_data == null && _error == null && !_loading) ...[
          const SizedBox(height: 60),
          Center(
            child: Column(
              children: [
                Icon(Icons.travel_explore,
                    size: 42, color: Brand.mint.withValues(alpha: 0.35)),
                const SizedBox(height: 14),
                Text('Search a stock to see which funds own it',
                    style: TextStyle(
                        color: Brand.mint.withValues(alpha: 0.7),
                        fontSize: 12.5)),
                const SizedBox(height: 6),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: Text(
                    'Weights come from each AMC\'s own monthly disclosure.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Brand.mint.withValues(alpha: 0.5),
                        fontSize: 10.5,
                        height: 1.4),
                  ),
                ),
              ],
            ),
          ),
        ],

        // ---- Multiple matching securities ----
        if (securities.length > 1) ...[
          const SizedBox(height: 14),
          Text('${securities.length} matching securities',
              style: TextStyle(
                  color: Brand.mint.withValues(alpha: 0.7), fontSize: 10.5)),
          const SizedBox(height: 7),
          SizedBox(
            height: 32,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: securities.length,
              itemBuilder: (context, i) {
                final s = (securities[i] as Map).cast<String, dynamic>();
                final active = i == _picked;
                return Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: GestureDetector(
                    onTap: () => setState(() => _picked = i),
                    child: Container(
                      alignment: Alignment.center,
                      padding: const EdgeInsets.symmetric(horizontal: 11),
                      decoration: BoxDecoration(
                        color: active
                            ? Brand.gold.withValues(alpha: 0.18)
                            : Brand.fern.withValues(alpha: 0.3),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: active
                              ? Brand.gold
                              : Brand.mint.withValues(alpha: 0.2),
                        ),
                      ),
                      child: Text(
                        '${s['instrument']}'.length > 26
                            ? '${'${s['instrument']}'.substring(0, 26)}…'
                            : '${s['instrument']}',
                        style: TextStyle(
                            color: active ? Brand.gold : Brand.mint,
                            fontSize: 10.5,
                            fontWeight:
                                active ? FontWeight.bold : FontWeight.normal),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],

        // ---- Selected security ----
        if (current != null) ...[
          const SizedBox(height: 16),
          Text('${current['instrument']}',
              style: const TextStyle(
                  color: Brand.paper,
                  fontSize: 14,
                  height: 1.3,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 3),
          Text('${current['industry']}',
              style: TextStyle(
                  color: Brand.gold.withValues(alpha: 0.85), fontSize: 11)),

          const SizedBox(height: 14),
          Row(
            children: [
              _StatTile(
                  label: 'FUNDS HOLDING',
                  value: '${current['fund_count']}'),
              _StatTile(
                  label: 'COMBINED VALUE',
                  value: '₹${_group((current['total_value_cr'] as num? ?? 0).round())} Cr',
                  colour: Brand.green),
              _StatTile(
                  label: 'TOP WEIGHT',
                  value: _pct(current['max_weight'] as num?),
                  colour: Brand.paper),
            ],
          ),

          const SizedBox(height: 18),
          Text('BY WEIGHT IN EACH FUND',
              style: TextStyle(
                  color: Brand.mint.withValues(alpha: 0.75),
                  fontSize: 9.5,
                  letterSpacing: 1,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6),
            decoration: BoxDecoration(
              color: Brand.fern.withValues(alpha: 0.22),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                for (final h in holders)
                  () {
                    final row = (h as Map).cast<String, dynamic>();
                    return _WeightBar(
                      label: '${row['fund']}',
                      pct: row['pct_nav'] as num?,
                      maxPct: maxWeight,
                      sub: _lakhToMoney(row['value_lakh'] as num?),
                    );
                  }(),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

// ===========================================================================
// TAB 2 — FUND PORTFOLIO
// ===========================================================================

class _PortfolioTab extends StatefulWidget {
  const _PortfolioTab({required this.funds});

  final List<dynamic> funds;

  @override
  State<_PortfolioTab> createState() => _PortfolioTabState();
}

class _PortfolioTabState extends State<_PortfolioTab> {
  String? _key;
  String? _label;
  Map<String, dynamic>? _data;
  bool _loading = false;
  String? _error;
  bool _showAll = false;

  Future<void> _load(String key) async {
    setState(() {
      _loading = true;
      _error = null;
      _data = null;
      _showAll = false;
    });
    try {
      final d = await ApiService.getFundHoldings(key);
      if (mounted) setState(() => _data = d);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final holdings = (_data?['holdings'] as List?) ?? [];
    final sectors = (_data?['sectors'] as List?) ?? [];
    final shown = _showAll ? holdings : holdings.take(15).toList();
    final maxWeight = holdings.isEmpty
        ? 1.0
        : ((holdings.first as Map)['pct_nav'] as num? ?? 1).toDouble();

    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
      children: [
        _FundPicker(
          funds: widget.funds,
          label: 'FUND',
          selected: _label,
          onSelect: (f) {
            setState(() {
              _key = '${f['key']}';
              _label = '${f['fund']}';
            });
            _load('${f['key']}');
          },
        ),

        if (_loading)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 60),
            child: Center(child: CircularProgressIndicator(color: Brand.gold)),
          ),

        if (_error != null)
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Text(_error!,
                style: const TextStyle(color: Brand.red, fontSize: 12)),
          ),

        if (_key == null && !_loading) ...[
          const SizedBox(height: 60),
          Center(
            child: Column(
              children: [
                Icon(Icons.pie_chart_outline,
                    size: 42, color: Brand.mint.withValues(alpha: 0.35)),
                const SizedBox(height: 14),
                Text('Choose a fund to see everything it owns',
                    style: TextStyle(
                        color: Brand.mint.withValues(alpha: 0.7),
                        fontSize: 12.5)),
              ],
            ),
          ),
        ],

        if (_data != null) ...[
          const SizedBox(height: 14),
          Row(
            children: [
              _StatTile(label: 'HOLDINGS', value: '${_data!['count']}'),
              _StatTile(
                  label: 'DISCLOSED',
                  value: _pct(_data!['disclosed_pct'] as num?, dp: 1),
                  colour: Brand.green),
              _StatTile(
                  label: 'TOP 10',
                  value: _pct(_data!['top10_pct'] as num?, dp: 1),
                  colour: Brand.paper),
            ],
          ),

          // ---- Sector allocation ----
          if (sectors.isNotEmpty) ...[
            const SizedBox(height: 20),
            Text('SECTOR ALLOCATION',
                style: TextStyle(
                    color: Brand.mint.withValues(alpha: 0.75),
                    fontSize: 9.5,
                    letterSpacing: 1,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            _SectorBar(sectors: sectors),
          ],

          // ---- Holdings ----
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_showAll
                      ? 'ALL ${holdings.length} HOLDINGS'
                      : 'TOP 15 HOLDINGS',
                  style: TextStyle(
                      color: Brand.mint.withValues(alpha: 0.75),
                      fontSize: 9.5,
                      letterSpacing: 1,
                      fontWeight: FontWeight.w700)),
              if (holdings.length > 15)
                GestureDetector(
                  onTap: () => setState(() => _showAll = !_showAll),
                  child: Text(_showAll ? 'Show less' : 'Show all',
                      style: const TextStyle(
                          color: Brand.gold,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w600)),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6),
            decoration: BoxDecoration(
              color: Brand.fern.withValues(alpha: 0.22),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                for (final h in shown)
                  () {
                    final row = (h as Map).cast<String, dynamic>();
                    return _WeightBar(
                      label: '${row['instrument']}',
                      pct: row['pct_nav'] as num?,
                      maxPct: maxWeight,
                      sub: _lakhToMoney(row['value_lakh'] as num?),
                    );
                  }(),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Disclosed weight is the share of NAV these holdings account for. '
            'The remainder is cash, derivatives, or instruments outside this '
            'disclosure.',
            style: TextStyle(
                color: Brand.mint.withValues(alpha: 0.5),
                fontSize: 10,
                height: 1.4),
          ),
        ],
      ],
    );
  }
}

/// Stacked sector bar plus a legend — a pie chart in a phone-width column
/// makes small slices unreadable.
class _SectorBar extends StatelessWidget {
  const _SectorBar({required this.sectors});

  final List<dynamic> sectors;

  @override
  Widget build(BuildContext context) {
    final top = sectors.take(9).toList();
    final rest = sectors.skip(9).fold<double>(
        0, (sum, s) => sum + (((s as Map)['pct_nav'] as num?) ?? 0));

    final segments = <(String, double, Color)>[
      for (var i = 0; i < top.length; i++)
        (
          '${(top[i] as Map)['industry']}',
          (((top[i] as Map)['pct_nav'] as num?) ?? 0).toDouble(),
          _sectorPalette[i % _sectorPalette.length],
        ),
      if (rest > 0.01) ('Others', rest, Brand.fern),
    ];

    final total = segments.fold<double>(0, (s, seg) => s + seg.$2);
    if (total <= 0) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: SizedBox(
            height: 12,
            child: Row(
              children: [
                for (final (_, pct, colour) in segments)
                  Expanded(
                    flex: math.max((pct * 100).round(), 1),
                    child: Container(color: colour),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 14,
          runSpacing: 8,
          children: [
            for (final (name, pct, colour) in segments)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                        color: colour,
                        borderRadius: BorderRadius.circular(2)),
                  ),
                  const SizedBox(width: 5),
                  Text(
                    '$name ${pct.toStringAsFixed(1)}%',
                    style: TextStyle(
                        color: Brand.mint.withValues(alpha: 0.8),
                        fontSize: 10),
                  ),
                ],
              ),
          ],
        ),
      ],
    );
  }
}

// ===========================================================================
// TAB 3 — OVERLAP
// ===========================================================================

class _OverlapTab extends StatefulWidget {
  const _OverlapTab({required this.funds});

  final List<dynamic> funds;

  @override
  State<_OverlapTab> createState() => _OverlapTabState();
}

class _OverlapTabState extends State<_OverlapTab> {
  String? _keyA, _keyB, _labelA, _labelB;
  Map<String, dynamic>? _data;
  bool _loading = false;
  String? _error;

  Future<void> _compare() async {
    if (_keyA == null || _keyB == null) return;
    if (_keyA == _keyB) {
      setState(() => _error = 'Pick two different funds');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
      _data = null;
    });
    try {
      final d = await ApiService.getFundOverlap(_keyA!, _keyB!);
      if (mounted) setState(() => _data = d);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final common = (_data?['common'] as List?) ?? [];
    final band = '${_data?['band'] ?? 'low'}';
    final colour = _overlapColour(band);
    final overlap = (_data?['overlap_pct'] as num?)?.toDouble() ?? 0;

    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
      children: [
        _FundPicker(
          funds: widget.funds,
          label: 'FUND A',
          selected: _labelA,
          onSelect: (f) {
            setState(() {
              _keyA = '${f['key']}';
              _labelA = '${f['fund']}';
            });
            _compare();
          },
        ),
        const SizedBox(height: 9),
        _FundPicker(
          funds: widget.funds,
          label: 'FUND B',
          selected: _labelB,
          onSelect: (f) {
            setState(() {
              _keyB = '${f['key']}';
              _labelB = '${f['fund']}';
            });
            _compare();
          },
        ),

        if (_loading)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 50),
            child: Center(child: CircularProgressIndicator(color: Brand.gold)),
          ),

        if (_error != null)
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Text(_error!,
                style: const TextStyle(color: Brand.red, fontSize: 12)),
          ),

        if (_data == null && !_loading && _error == null) ...[
          const SizedBox(height: 50),
          Center(
            child: Column(
              children: [
                Icon(Icons.join_inner,
                    size: 42, color: Brand.mint.withValues(alpha: 0.35)),
                const SizedBox(height: 14),
                Text('Pick two funds to compare',
                    style: TextStyle(
                        color: Brand.mint.withValues(alpha: 0.7),
                        fontSize: 12.5)),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 36),
                  child: Text(
                    'High overlap means two funds hold much the same stocks — '
                    'owning both may add less diversification than it appears.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Brand.mint.withValues(alpha: 0.5),
                        fontSize: 10.5,
                        height: 1.45),
                  ),
                ),
              ],
            ),
          ),
        ],

        if (_data != null) ...[
          const SizedBox(height: 18),

          // ---- Headline ----
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: colour.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: colour.withValues(alpha: 0.35)),
            ),
            child: Column(
              children: [
                Text('PORTFOLIO OVERLAP',
                    style: TextStyle(
                        color: Brand.mint.withValues(alpha: 0.8),
                        fontSize: 9.5,
                        letterSpacing: 1,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Text('${overlap.toStringAsFixed(1)}%',
                    style: TextStyle(
                        color: colour,
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                        height: 1)),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: SizedBox(
                    height: 7,
                    child: Row(
                      children: [
                        Expanded(
                          flex: math.max(overlap.round(), 1),
                          child: Container(color: colour),
                        ),
                        Expanded(
                          flex: math.max((100 - overlap).round(), 1),
                          child: Container(
                              color: Brand.fern.withValues(alpha: 0.6)),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text('${_data!['verdict']}',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: colour,
                        fontSize: 12,
                        height: 1.4,
                        fontWeight: FontWeight.w600)),
              ],
            ),
          ),

          const SizedBox(height: 12),
          Row(
            children: [
              _StatTile(
                  label: 'SHARED STOCKS',
                  value: '${_data!['common_count']}'),
              _StatTile(
                  label: 'IN FUND A',
                  value: '${(_data!['fund_a'] as Map)['holdings']}',
                  colour: Brand.paper),
              _StatTile(
                  label: 'IN FUND B',
                  value: '${(_data!['fund_b'] as Map)['holdings']}',
                  colour: Brand.paper),
            ],
          ),

          // ---- Shared holdings ----
          if (common.isNotEmpty) ...[
            const SizedBox(height: 20),
            Text('SHARED HOLDINGS BY WEIGHT',
                style: TextStyle(
                    color: Brand.mint.withValues(alpha: 0.75),
                    fontSize: 9.5,
                    letterSpacing: 1,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Row(
              children: [
                Container(width: 9, height: 9, color: Brand.gold),
                const SizedBox(width: 5),
                Expanded(
                  child: Text(_labelA ?? 'Fund A',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: Brand.mint.withValues(alpha: 0.8),
                          fontSize: 10)),
                ),
                const SizedBox(width: 10),
                Container(width: 9, height: 9, color: Brand.green),
                const SizedBox(width: 5),
                Expanded(
                  child: Text(_labelB ?? 'Fund B',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: Brand.mint.withValues(alpha: 0.8),
                          fontSize: 10)),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
              decoration: BoxDecoration(
                color: Brand.fern.withValues(alpha: 0.22),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  for (final c in common.take(20))
                    () {
                      final row = (c as Map).cast<String, dynamic>();
                      return _OverlapRow(
                        instrument: '${row['instrument']}',
                        pctA: (row['pct_a'] as num?)?.toDouble() ?? 0,
                        pctB: (row['pct_b'] as num?)?.toDouble() ?? 0,
                      );
                    }(),
                ],
              ),
            ),
            if (common.length > 20) ...[
              const SizedBox(height: 8),
              Text('Showing the 20 largest shared positions of '
                  '${_data!['common_count']}.',
                  style: TextStyle(
                      color: Brand.mint.withValues(alpha: 0.55),
                      fontSize: 10)),
            ],
          ],

          const SizedBox(height: 12),
          Text(
            'Overlap is the sum of the smaller weight of each shared holding. '
            'If both funds hold 5% of the same stock they overlap 5% there; '
            'if one holds 5% and the other 2%, they overlap 2%.',
            style: TextStyle(
                color: Brand.mint.withValues(alpha: 0.5),
                fontSize: 10,
                height: 1.45),
          ),
        ],
      ],
    );
  }
}

/// One shared holding, showing both funds' weights on a common scale.
class _OverlapRow extends StatelessWidget {
  const _OverlapRow({
    required this.instrument,
    required this.pctA,
    required this.pctB,
  });

  final String instrument;
  final double pctA;
  final double pctB;

  @override
  Widget build(BuildContext context) {
    final scale = math.max(math.max(pctA, pctB), 0.01);

    Widget bar(double pct, Color colour) => Row(
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(2),
                child: SizedBox(
                  height: 4,
                  child: Row(
                    children: [
                      Expanded(
                        flex: math.max((pct / scale * 1000).round(), 1),
                        child: Container(color: colour),
                      ),
                      Expanded(
                        flex: math.max(
                            ((1 - pct / scale) * 1000).round(), 1),
                        child: Container(
                            color: Brand.fern.withValues(alpha: 0.45)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 7),
            SizedBox(
              width: 40,
              child: Text('${pct.toStringAsFixed(2)}%',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                      color: colour,
                      fontSize: 9.5,
                      fontWeight: FontWeight.w600)),
            ),
          ],
        );

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(instrument,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Brand.paper, fontSize: 11.5)),
          const SizedBox(height: 5),
          bar(pctA, Brand.gold),
          const SizedBox(height: 3),
          bar(pctB, Brand.green),
        ],
      ),
    );
  }
}
